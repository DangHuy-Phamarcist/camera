﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WpfCameraConnectApp
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private async void ConnectButton_Click(object sender, RoutedEventArgs e)
        {
            string cameraIp = CameraIpTextBox.Text;
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(cameraIp) || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter camera IP, username, and password.");
                return;
            }

            string apiUrl = $"http://{cameraIp}/cgi-bin/magicBox.cgi?action=getSystemInfo"; // Thay thế với API chính xác của camera

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    // Thiết lập thông tin xác thực (nếu cần)
                    var byteArray = Encoding.ASCII.GetBytes($"{username}:{password}");
                    client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", Convert.ToBase64String(byteArray));

                    // Gửi yêu cầu GET tới API của camera
                    HttpResponseMessage response = await client.GetAsync(apiUrl);

                    if (response.IsSuccessStatusCode)
                    {
                        // Đọc nội dung phản hồi từ camera
                        string responseBody = await response.Content.ReadAsStringAsync();
                        ResultTextBlock.Text = "Thông tin camera nhận được:\n" + responseBody;
                    }
                    else
                    {
                        ResultTextBlock.Text = $"Không thể kết nối tới camera. Mã lỗi HTTP: {response.StatusCode}";
                    }
                }
            }
            catch (Exception ex)
            {
                ResultTextBlock.Text = $"Lỗi kết nối với camera: {ex.Message}";
            }
        }
    }
}
